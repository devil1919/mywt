<?php

$con = mysqli_connect('127.0.0.1', 'root', '');

if(!$con)
{
    echo 'Not connected to server';
}

if(!mysqli_select_db($con, 'test'))
{
    echo 'Database not selected';
}

$sql1 = "Select * from users";

?>


<html>
<table>
    <tr>
        <th>Name</th>
        <th>Age</th>
        <th>city</th>
    </tr>
    
    <?php
$result =$con-> query($sql1);

if($result-> num_rows >0)
{
    while ($row = $result-> fetch_assoc())
    {
        echo "<tr><td>".$row["name"]."<tr><td>".$row["age"]."<tr><td>".$row["city"]."<tr><td>";
    }
    echo '</table>';
}
 else {
    echo 'Result not Found!';    
}

$con->close();
?>
</html>
     
