/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EJBDemoFinal;

/**
 *
 * @author ADMIN
 */
import javax.ejb.Stateless;

@Stateless
public class EJBSessionBeans {

    private int i,j,k;

    public int getI() {       return i;    }

    public void setI(int i) {         this.i = i;    }

    public int getJ() {         return j;     }

    public void setJ(int j) {        this.j = j;    }

    public int getK() {        return k;    }

    public void setK(int k) {        this.k = k;    }
    
   public int add()    {         int k=i+j;        return k;    }
   public int Subtract()   {         int k=i-j;       return k;    }
   public int Multiply()    {         int k=i*j;        return k;    }    
   public int Division()    {         int k=i/j;        return k;    }
    
}

