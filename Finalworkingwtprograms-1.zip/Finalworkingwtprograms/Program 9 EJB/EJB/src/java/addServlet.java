/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ADMIN
 */
import EJBDemoFinal.EJBSessionBeans;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/addServlet"})
public class addServlet extends HttpServlet {

    @EJB
    EJBSessionBeans obj;

    public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        PrintWriter pt = res.getWriter();
        int i = Integer.parseInt(req.getParameter("t1"));
        int j = Integer.parseInt(req.getParameter("t2"));
        obj.setI(i);
        obj.setJ(j);

        int k = obj.add();
        pt.println("Addition is using EJB :" + k);
        pt.println("<br>");
        pt.println("Subtraction is using EJB :" + obj.Subtract());
        pt.println("<br>");
        pt.println("Multiplication is using EJB :" + obj.Multiply());
        pt.println("<br>");
        pt.println("Division is using EJB :" + obj.Division());
    }

}
